# Transcriber — UI design brief

Source of truth: `D:\Local\Git\transcriber\apps\desktop\src\`. This brief describes
the app as it exists today, every state the UI must be able to render, and the
constraints a redesign has to respect.

---

## 1. The product in one paragraph

**Transcriber** is a local, Windows-first desktop app. You drag a meeting
recording onto it; it (a) files the file into a structured "meetings vault"
folder on disk, and (b) transcribes it locally with faster-whisper `large-v3`
on the GPU. Nothing is uploaded. The output is a `transcript.json` sitting next
to the recording in its own meeting folder.

It is a **single-window utility**, not a content app. The user drops files and
leaves. There is no library, no browsing, no transcript viewer, no editing, no
account, no settings page beyond one folder path.

## 2. Who uses it and how

One person on their own Windows 11 machine, typically right after a call.
Realistic session: open (or it is already open) → drag 1–3 files in → watch them
go green → click "Reveal" to open the folder → leave. Elapsed attention: seconds,
then periodic glances while a long transcription runs (a 1-hour recording takes
minutes).

Design implications the current UI does **not** yet exploit:
- The job list is the app. Everything else is setup that happens once.
- Progress is the thing people glance at from across the desk.
- The window is often left open in the background while other work happens.

## 3. Hard technical constraints

| Constraint | Detail |
|---|---|
| Shell | Tauri 2 → WebView2 (Chromium) on Windows 11. Modern CSS is fine. |
| Default window | 1100 × 760, resizable. Must survive down to ~700 × 500. |
| Stack | React 18 + TypeScript + Vite. **No UI framework, no CSS framework, no icon package installed.** Styling is plain CSS Modules per component plus one global `styles.css`. |
| CSP | `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'` — **no external fonts, no CDN, no remote images.** Anything visual must be system fonts, CSS, or inline SVG. |
| Theme | `color-scheme: light dark` is already declared; the app has no explicit dark palette yet. Both themes should work. |
| Native drag & drop | Handled by Tauri (`dragDropEnabled: true`), **not** HTML5 DnD. The webview receives `enter`/`over`/`leave`/`drop` events carrying absolute file paths. The drop target is effectively the whole window; the visual drop zone is a hint, not a hit target. |
| Dialogs | Native Windows file/folder pickers via the Tauri dialog plugin. |
| Data access | The UI never touches the filesystem or network directly. All data arrives through 9 IPC commands and 2 events. |

## 4. Current layout

One flat vertical stack, `max-width: 960px`, `gap: 0.75rem`, no chrome:

```
┌────────────────────────────────────────────────────────┐
│ Transcriber                              (h1, 1.1rem)  │
│ [config error banner — only if config.json was broken] │
│ D:\MeetingVault                          [ Change... ] │  ← SettingsBar
│ [service banner — only when starting/unavailable]      │  ← ServiceBanner
│ ┌────────────────────────────────────────────────────┐ │
│ │ Drop a recording here, or choose a file.           │ │  ← DropZone
│ │                                    [ Choose file ] │ │    (or FirstRun)
│ └────────────────────────────────────────────────────┘ │
│ [model download step — only until the model is present]│  ← ModelDownloadStep
│ ── Jobs ───────────────────────────────────────────────│
│  ELS - 260812 - Security issue.mp4  Transcribing sorted│  ← JobRow ×N
│  D:\MeetingVault\ELS\260812 - Security issue [ Reveal ]│
│ [last error, if any]                                   │
└────────────────────────────────────────────────────────┘
```

Total component CSS today: ~119 lines across 7 modules. The design tokens in
`styles.css` are the whole system:

```css
--border-color: #888;   --accent-color: #2563eb;  --hover-bg: rgba(37,99,235,.08);
--busy-color: #b45309;  --warning-color: #b91c1c; --muted-color: #666;
```

It is deliberately utilitarian and, honestly, unfinished-looking. That is what
we want redesigned.

## 5. Every state the UI must render

This is the exhaustive list. A redesign needs to cover all of it.

### 5.1 App-level gates (mutually exclusive, top of the window)

1. **First run — no vault folder chosen.** The drop zone is *replaced* by a
   folder prompt; drops are actively refused. Exactly one action exists:
   "Choose folder…". This is the blank slate, and it currently gets two lines of
   text.
2. **Vault folder configured** → normal operation.
3. **Config file was corrupt** → persistent alert: settings were reset to
   defaults, with the raw parse error appended.
4. **Vault folder no longer exists** (drive unplugged, folder moved) → warning
   attached to the folder path: "This folder no longer exists. Choose a valid
   meetings folder."

### 5.2 Service (the local Python transcription sidecar)

Three states, from the `service://status` event:
- `starting` — "Starting the transcription service…" (up to 30 s on a cold start).
- `ready` — **renders nothing.** Silence is success.
- `unavailable` — persistent banner. Important nuance to preserve: *filing still
  works while transcription is down.* The message says recordings already filed
  are safe and can be re-dropped later. This is a degraded state, not a failure.

### 5.3 Model download (first run, ~3 GB)

States: `idle` · `downloading` · `verifying` · `complete` · `cancelled` · `error`,
plus a `model_present` boolean and a separate CUDA-runtime concern. Modes:
- **Full step** — heading, explanation, `Start download` + `Skip for now`.
- **Downloading / verifying** — the string `"1.5 GB / 3.0 GB (50%)"`, polled every
  1000 ms, with `Cancel`. **There is no progress bar today — just that string.**
- **Cancelled / error** — message + `Retry` + `Skip for now`.
- **Compact notice** — what "Skip for now" leaves behind: a persistent one-liner,
  "The transcription model is still missing." + `Retry`, with the rest of the app
  usable underneath.
- **GPU runtime notice** — separate from the model: the model is present, but the
  ~1.4 GB CUDA runtime failed or is missing, so transcription runs on CPU (slow,
  but working). Shows the backend's verbatim message + `Retry GPU setup`, and its
  own download/verify progress while that retry is in flight.

### 5.4 Drop zone

`idle` → "Drop a recording here, or choose a file." ·
`hovering` → "Release to add this file." ·
`working` → "Filing dropped file(s)…"
Plus a `Choose file…` button (the non-drag path).

### 5.5 Job list — the core surface

Rows are append-only for the session, in submission order, upserted by id.
**There is no history: the list is empty on every launch.** Seven states:

| State | Label today | Meaning |
|---|---|---|
| `pending` | Pending | accepted, not started |
| `ingesting` | Filing into vault | copying/moving into the vault folder |
| `queued` | Queued | handed to the service, waiting |
| `running` | Transcribing | actual inference — the long one |
| `done` | Done | `transcript.json` written |
| `failed` | Failed | transcription failed; the file is still safely filed |
| `rejected` | Rejected | not a supported recording type; nothing was filed |

Each row carries: file name, state, a `sorted` / `unsorted` classification tag, an
optional message, a `progress` number (0–1, **currently not rendered at all**),
and the deepest known path (transcript → filed source → meeting folder) with a
`Reveal` button that opens Explorer.

Two domain concepts worth surfacing better than today:
- **sorted vs unsorted.** A file named `ELS - 260812 - Security issue.mp4` parses
  into project / date / title and lands in `<VAULT>\ELS\260812 - Security issue\`.
  Anything else still gets filed, into `<VAULT>\unsorted\<date> - <name>\`. It is
  never rejected for a bad name — that is a deliberate product promise, and the UI
  should make "we filed it, just not sorted" feel fine rather than like an error.
- **Jobs run one at a time**, in order. Only one row is ever `running`.

### 5.6 Errors

A single `lastError` line at the bottom, drawn from a 12-value taxonomy:
`not_configured` · `invalid_argument` · `outside_root` · `unsupported_extension` ·
`not_a_file` · `vault` · `collision` · `service_unavailable` · `service` ·
`config` · `io` · `internal`. Each arrives with a human message from the Rust side.

## 6. The complete interaction inventory

The user can do exactly five things. That is the whole app:

1. Drop files on the window
2. Choose a file through a native dialog
3. Choose / change the vault folder
4. Start, cancel, retry, or skip the model download
5. Reveal a job's folder in Explorer

No sorting, no filtering, no clearing the list, no retrying a job, no cancelling a
job, no opening a transcript. Some of those are worth *proposing* — just flag them
as new, since they need backend work.

## 7. Data shapes (for realistic mockups)

```ts
type JobSnapshot = {
  id: string;
  source_path: string;      // C:\Users\me\Downloads\ELS - 260812 - Security issue.mp4
  file_name: string;        // ELS - 260812 - Security issue.mp4
  state: "pending"|"ingesting"|"queued"|"running"|"done"|"failed"|"rejected";
  classification: "sorted" | "unsorted" | null;
  meeting_dir: string | null;      // D:\MeetingVault\ELS\260812 - Security issue
  source_dest: string | null;      // ...\source.mp4
  transcript_path: string | null;  // ...\transcript.json
  progress: number | null;         // 0..1 — NOT rendered today
  message: string | null;
  error_kind: string | null;
  created_at: string;
};

type SettingsView = {
  meetings_root: string | null;         // D:\MeetingVault
  meetings_root_exists: boolean;
  service_base_url: string | null;      // http://127.0.0.1:53412
  supported_extensions: string[];       // mp4 mkv mov webm avi m4a mp3 wav flac ogg
  config_error: string | null;
  default_meetings_root: string | null;
};

type ServiceStatusView = {
  state: "starting" | "ready" | "unavailable";
  base_url: string | null;
  detail: string | null;
};

type ModelDownloadStatus = {
  state: "idle"|"downloading"|"verifying"|"complete"|"cancelled"|"error";
  downloaded_bytes: number; total_bytes: number; percent: number;
  error_kind: string | null; error_message: string | null;
  model_present: boolean;
  cuda_warning: string | null;
  cuda_runtime_present: boolean | null;   // null = no GPU on this machine
};
```

Realistic sample filenames: `ELS - 260812 - Security issue.mp4`,
`ACME - 260731 - Weekly sync - part 2.m4a`, `zoom_recording_2026_08_14.mp4`
(→ unsorted), `Screen Recording 2026-08-01 at 14.22.31.mov` (→ unsorted).

## 8. Where the current UI falls short

These are the design problems to solve, not a fixed to-do list:

1. **No visual hierarchy.** Seven sibling blocks stacked with an equal 0.75rem
   gap. The job list — the thing that matters — carries no more weight than the
   settings path.
2. **`progress` is never drawn.** A 1-hour transcription shows the word
   "Transcribing" and nothing else for several minutes. Same for the model
   download, which shows only a text string for a multi-gigabyte transfer.
3. **The drop zone is undersized for its role.** Dropping is the primary action
   and the whole window is the real drop target, but the visual affordance is a
   small bordered box that gets shoved around by whatever banners are visible.
4. **The empty state is bare.** A cold start with a configured vault shows a drop
   zone and an empty `<ul>`. Nothing explains the naming convention, the sorted/
   unsorted behaviour, or where files end up.
5. **First run is three separate hurdles** — choose folder, download model,
   optionally install the GPU runtime — presented as three unrelated blocks that
   appear at different moments rather than as one setup path.
6. **Job rows are a flat run of spans.** File name, state, tag, message and a long
   absolute path all sit at the same level with no grouping.
7. **Degraded states read as errors.** "Service unavailable" and "unsorted" are
   both *fine* — the app still did its job — but they look like failures.
8. **No dark theme**, despite `color-scheme: light dark` being declared.
9. **No iconography and no motion at all.** Not asking for decoration — asking for
   the minimum that makes state legible at a glance.

## 9. What must not change

- **Component boundaries.** `DropZone`, `FirstRun`, `SettingsBar`, `ServiceBanner`,
  `ModelDownloadStep`, `JobList`, `JobRow` are strictly presentational: no
  `invoke`, no `listen`, no `fetch`. All IPC lives in `api.ts` / `App.tsx`. Keep
  that split — new subcomponents are fine.
- **The IPC contract** in `src/types.ts` is frozen and mirrors the Rust side. A
  design may render fewer or more of these fields, but cannot invent new ones
  without backend work — call it out explicitly if a design needs new data.
- **Accessibility hooks the tests assert on**: `role="region"` with accessible
  names ("Drop zone", "Settings", "Jobs"), `role="alert"` for errors,
  `role="status"` for progress/busy text, and `data-state="…"` attributes on the
  drop zone, job rows and the model step. Roughly 1,100 lines of component tests
  select on these plus visible label text — changing wording is allowed, but flag
  it so the tests get updated in the same change.
- **`Reveal` passes a job id**, never a path string.
- **No new runtime dependencies** without asking — the CSP plus the offline,
  single-executable install make external assets a real problem.

## 10. What I want out of the design pass

A redesign of the single window covering, at minimum:

1. **Idle / working state** — vault configured, model present, 3–4 jobs in mixed
   states (one running with real progress, one done, one unsorted, one failed).
2. **Empty state** — configured but nothing dropped yet, teaching the naming
   convention without a wall of text.
3. **First-run setup** — folder → model download → optional GPU runtime, as one
   coherent path rather than three stacked cards.
4. **Degraded state** — service unavailable while files still file successfully.
5. **A token set** (color, type scale, spacing, radius, interaction states) that
   works in both light and dark, expressed as CSS custom properties so it drops
   into `styles.css` and the existing per-component CSS Modules.

Tone: a precise local tool — closer to a good Windows utility than to a SaaS
dashboard. Dense but not cramped, quiet, no marketing chrome. It should look
trustworthy with your recordings.
