repo: leins275/transcriber
branch: main
path: apps/desktop/src

## Last sync
date: 2026-08-22T14:58:00Z

### Updated in this project
- Read App.tsx, types.ts, JobRow.tsx, ModelDownloadStep.tsx, styles.css to ground the redesign
- Drafted two redesign directions (Ledger / Colophon) in Transcriber Redesign.dc.html

## Screen map
| Screen | Repo files |
| --- | --- |
| Transcriber Redesign.dc.html | apps/desktop/src/App.tsx, apps/desktop/src/types.ts, apps/desktop/src/styles.css, apps/desktop/src/components/JobRow.tsx, apps/desktop/src/components/ModelDownloadStep.tsx, apps/desktop/src/components/DropZone.tsx, apps/desktop/src/components/SettingsBar.tsx, apps/desktop/src/components/ServiceBanner.tsx |
